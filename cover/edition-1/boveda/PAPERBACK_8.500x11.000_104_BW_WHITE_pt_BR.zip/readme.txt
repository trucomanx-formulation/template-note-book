“Como usar o modelo”

1. Abra o arquivo PDF ou PNG do modelo de capa para livros com capa comum no seu software de edição de imagens.
2. Crie uma nova camada no seu software de edição de imagens. Essa camada será a camada de design.
3. Crie sua capa na camada de design, usando o arquivo de modelo em PDF ou PNG como camada-guia. A arte deve ultrapassar a borda externa da zona rosa do modelo para que a borda branca não apareça quando o livro for impresso. Não mova a camada-guia, pois ela já está alinhada conforme nossas especificações de impressão.
4. Certifique-se de que textos e/ou imagens que devam ser lidos não estejam nas zonas rosas do modelo.
5. A área do código de barras está indicada em amarelo no modelo. Não coloque imagens importantes ou textos que devam ser lidos na área do código de barras. Sugerimos que você preencha essa área com sua cor de fundo ou design. O KDP gerará automaticamente um código de barras representando o ISBN do seu livro quando as cópias forem impressas.
6. Assim que concluir seu design, será necessário desativar a camada-guia para que ela não seja impressa no produto final, o que pode fazer com que seu livro seja rejeitado durante o processo de revisão. Se não conseguir desativar a camada-guia, você precisará formatar a arte para que ela cubra totalmente essa camada.
7. Mescle todas as camadas, salve o arquivo como PDF com o perfil de cores CMYK e faça o upload do arquivo pelo KDP.
